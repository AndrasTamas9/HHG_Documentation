var annotated_dup =
[
    [ "hhg_pinGUIn", null, [
      [ "Listener", "classhhg__pinGUIn_1_1Listener.html", null ]
    ] ]
];