var searchData=
[
  ['w0_0',['w0',['../hhg_8cpp.html#a78f35a2a3d20e9d68f94a0ecd1e0a79c',1,'hhg.cpp']]]
];
