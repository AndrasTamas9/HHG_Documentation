var searchData=
[
  ['omega_0',['omega',['../hhg_8cpp.html#a98ecc32b7ac0cf654d9f883cbe5cab35',1,'hhg.cpp']]]
];
