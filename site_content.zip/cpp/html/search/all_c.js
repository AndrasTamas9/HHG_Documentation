var searchData=
[
  ['perform_5fconvergence_5fanalysis_0',['perform_convergence_analysis',['../convergence_8cpp.html#ae221d6c2b3ef9964d468250fac189e17',1,'convergence.cpp']]],
  ['phi_1',['phi',['../hhg_8cpp.html#adae8d8a6ff28515e505bb1c07f2b33c8',1,'hhg.cpp']]],
  ['pi_2',['PI',['../hhg_8cpp.html#a952eac791b596a61bba0a133a3bb439f',1,'hhg.cpp']]]
];
