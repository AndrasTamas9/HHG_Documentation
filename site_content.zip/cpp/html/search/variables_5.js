var searchData=
[
  ['size_0',['SIZE',['../hhg_8cpp.html#af08413a3ee12cf78b0ddeea71e2648b3',1,'hhg.cpp']]],
  ['stop_5frequested_1',['stop_requested',['../convergence_8cpp.html#ab416d9ae629691be1be31c5a34158d62',1,'stop_requested:&#160;convergence.cpp'],['../hhg_8cpp.html#ab416d9ae629691be1be31c5a34158d62',1,'stop_requested:&#160;hhg.cpp']]]
];
