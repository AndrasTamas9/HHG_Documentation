var searchData=
[
  ['compare_5fby_5fn_0',['compare_by_n',['../convergence_8cpp.html#a2ef7865564f2c92dd18a155981ef4a03',1,'convergence.cpp']]],
  ['computefft_5fdmat_1',['computeFFT_Dmat',['../hhg_8cpp.html#ad727678cf74b10d8a845d688ea11e1e6',1,'hhg.cpp']]],
  ['computeprimitivesimpson3d_2',['computePrimitiveSimpson3D',['../hhg_8cpp.html#a665f0a911388c5be8cc614c022decc3b',1,'hhg.cpp']]]
];
