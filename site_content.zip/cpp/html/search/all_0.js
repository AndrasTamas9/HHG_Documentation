var searchData=
[
  ['_5fuse_5fmath_5fdefines_0',['_USE_matH_DEFINES',['../hhg_8cpp.html#a213ac209bfa986bb94b234605d7f2017',1,'hhg.cpp']]]
];
