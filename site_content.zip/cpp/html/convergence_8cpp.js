var convergence_8cpp =
[
    [ "area_between", "convergence_8cpp.html#ab6087d49471051e2b345a21952eefa9b", null ],
    [ "area_under", "convergence_8cpp.html#a83640ef12fa72924a1b57dd5af273a29", null ],
    [ "compare_by_n", "convergence_8cpp.html#a2ef7865564f2c92dd18a155981ef4a03", null ],
    [ "extract_n", "convergence_8cpp.html#a55700406e381845f03b5ba3aa93131cb", null ],
    [ "generate_D_files", "convergence_8cpp.html#a0b24765d1cf91610866bcfab4d31544b", null ],
    [ "interpolate", "convergence_8cpp.html#ae94efd2f6e9bcf9ed53edc6617946614", null ],
    [ "perform_convergence_analysis", "convergence_8cpp.html#ae221d6c2b3ef9964d468250fac189e17", null ],
    [ "read_data", "convergence_8cpp.html#a835b34e653692f1d0288c6e53fa4e49d", null ],
    [ "requestStop", "convergence_8cpp.html#a2aa559ccfac14379f5551d7d802a3749", null ],
    [ "runConvergence", "convergence_8cpp.html#a5a7875a1e0ab3a34230ed33ce6a9a6f4", null ],
    [ "stop_requested", "convergence_8cpp.html#ab416d9ae629691be1be31c5a34158d62", null ]
];