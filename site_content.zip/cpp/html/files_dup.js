var files_dup =
[
    [ "convergence.cpp", "convergence_8cpp.html", "convergence_8cpp" ],
    [ "hhg.cpp", "hhg_8cpp.html", "hhg_8cpp" ]
];